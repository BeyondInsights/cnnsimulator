/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    allowedDevOrigins: [
      "https://3000-firebase-news-optimizer-1748488005153.cluster-joak5ukfbnbyqspg4tewa33d24.cloudworkstations.dev"
    ],
  },
};

module.exports = nextConfig;

